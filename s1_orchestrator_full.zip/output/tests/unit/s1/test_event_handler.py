"""Tests for s1_orchestrator.event_handler."""
from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from shared.constants import ApprovalMode, SystemMode
from s1_orchestrator.event_handler import EventHandler


def make_session(events=None):
    """Build a session mock that returns events from a single-filter query chain.

    EventHandler._poll() uses:
      session.query(X).filter(A, B).order_by(C).all()
    """
    session = MagicMock()
    session.__enter__ = MagicMock(return_value=session)
    session.__exit__ = MagicMock(return_value=False)
    (
        session.query.return_value
        .filter.return_value
        .order_by.return_value
        .all.return_value
    ) = events or []
    return session


class TestModeChangedHandling:
    def test_mode_changed_calls_on_mode_changed_callback(self):
        received = []

        def on_mode_changed(mode, approval):
            received.append((mode, approval))

        event = MagicMock()
        event.event_type = "MODE_CHANGED"
        event.timestamp = datetime.now(tz=timezone.utc)
        session = make_session(events=[event])

        mock_cfg = MagicMock()
        mock_cfg.system.mode = "LIVE"
        mock_cfg.system.approval_mode = "HARD"

        with patch("s1_orchestrator.event_handler.get_session", return_value=session), \
             patch("s1_orchestrator.event_handler.get_config", return_value=mock_cfg), \
             patch("s1_orchestrator.event_handler.invalidate_cache"):
            handler = EventHandler(
                on_mode_changed=on_mode_changed,
                on_config_changed=lambda: None,
                poll_interval_seconds=999,
            )
            handler._poll()

        assert len(received) == 1
        mode, approval = received[0]
        assert mode == SystemMode.LIVE
        assert approval == ApprovalMode.HARD

    def test_invalidate_cache_called_on_mode_change(self):
        event = MagicMock()
        event.event_type = "MODE_CHANGED"
        event.timestamp = datetime.now(tz=timezone.utc)
        session = make_session(events=[event])

        mock_cfg = MagicMock()
        mock_cfg.system.mode = "PAPER"
        mock_cfg.system.approval_mode = "HARD"

        with patch("s1_orchestrator.event_handler.get_session", return_value=session), \
             patch("s1_orchestrator.event_handler.get_config", return_value=mock_cfg), \
             patch("s1_orchestrator.event_handler.invalidate_cache") as mock_inv:
            handler = EventHandler(
                on_mode_changed=lambda m, a: None,
                on_config_changed=lambda: None,
                poll_interval_seconds=999,
            )
            handler._poll()

        mock_inv.assert_called_once()


class TestConfigChangedHandling:
    def test_config_changed_calls_on_config_changed_callback(self):
        called = []

        def on_config_changed():
            called.append(True)

        event = MagicMock()
        event.event_type = "CONFIG_CHANGED"
        event.timestamp = datetime.now(tz=timezone.utc)
        session = make_session(events=[event])

        with patch("s1_orchestrator.event_handler.get_session", return_value=session), \
             patch("s1_orchestrator.event_handler.invalidate_cache"):
            handler = EventHandler(
                on_mode_changed=lambda m, a: None,
                on_config_changed=on_config_changed,
                poll_interval_seconds=999,
            )
            handler._poll()

        assert called == [True]

    def test_invalidate_cache_called_on_config_change(self):
        event = MagicMock()
        event.event_type = "CONFIG_CHANGED"
        event.timestamp = datetime.now(tz=timezone.utc)
        session = make_session(events=[event])

        with patch("s1_orchestrator.event_handler.get_session", return_value=session), \
             patch("s1_orchestrator.event_handler.invalidate_cache") as mock_inv:
            handler = EventHandler(
                on_mode_changed=lambda m, a: None,
                on_config_changed=lambda: None,
                poll_interval_seconds=999,
            )
            handler._poll()

        mock_inv.assert_called_once()


class TestNoEvents:
    def test_no_events_does_nothing(self):
        called = []
        session = make_session(events=[])

        with patch("s1_orchestrator.event_handler.get_session", return_value=session):
            handler = EventHandler(
                on_mode_changed=lambda m, a: called.append("mode"),
                on_config_changed=lambda: called.append("cfg"),
                poll_interval_seconds=999,
            )
            handler._poll()

        assert called == []


class TestWatermarkAdvances:
    def test_watermark_moves_to_latest_event_timestamp(self):
        t1 = datetime(2026, 1, 1, 10, 0, 0, tzinfo=timezone.utc)
        t2 = datetime(2026, 1, 1, 10, 5, 0, tzinfo=timezone.utc)

        e1 = MagicMock()
        e1.event_type = "CONFIG_CHANGED"
        e1.timestamp = t1

        e2 = MagicMock()
        e2.event_type = "CONFIG_CHANGED"
        e2.timestamp = t2

        session = make_session(events=[e1, e2])

        with patch("s1_orchestrator.event_handler.get_session", return_value=session), \
             patch("s1_orchestrator.event_handler.invalidate_cache"):
            handler = EventHandler(
                on_mode_changed=lambda m, a: None,
                on_config_changed=lambda: None,
            )
            handler._poll()

        assert handler._watermark == t2


class TestLifecycle:
    def test_start_stop(self):
        session = make_session(events=[])
        with patch("s1_orchestrator.event_handler.get_session", return_value=session):
            handler = EventHandler(
                on_mode_changed=lambda m, a: None,
                on_config_changed=lambda: None,
                poll_interval_seconds=999,
            )
            handler.start()
            assert handler._thread.is_alive()
            handler.stop()
            assert not handler._thread.is_alive()
